/* ============================================================
   GAME.JS — Restaurante VR
   ============================================================
   Escena 3D del restaurante (Three.js), movimiento del jugador
   en primera persona y todas las mecánicas de cocina: agarrar
   con la pinza de la mano, abrir puertas, encender la estufa,
   picar con el cuchillo, remover con la espátula, cocinar,
   descartar en la caneca y servir pedidos.

   Este archivo NO toca MediaPipe directamente: todo el estado
   de las manos se lee de `window.HandTracking.hands.left/right`
   (publicado por tracking.js) una vez por frame.
   ============================================================ */

(() => {

// ══════════════════════════════════════════════════════════
// UTILIDADES
// ══════════════════════════════════════════════════════════
function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function rand(a, b) { return a + Math.random() * (b - a); }

function makeTexture(draw, size = 64, repeat = [1, 1]) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  draw(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat[0], repeat[1]);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function makeTextPanel(line1, line2, w = 512, h = 192) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#3a2414'; ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = '#caa46b'; ctx.lineWidth = 6; ctx.strokeRect(6, 6, w - 12, h - 12);
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#ffdd99';
  ctx.font = 'bold 44px Georgia, serif';
  ctx.fillText(line1, w / 2, h / 2 - (line2 ? 24 : 0));
  if (line2) {
    ctx.font = '24px Georgia, serif';
    ctx.fillStyle = '#e6b978';
    ctx.fillText(line2, w / 2, h / 2 + 34);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

// ══════════════════════════════════════════════════════════
// TEXTURAS DEL ENTORNO
// ══════════════════════════════════════════════════════════
const TX_FLOOR = makeTexture((ctx, s) => {
  ctx.fillStyle = '#caa46b'; ctx.fillRect(0, 0, s, s);
  ctx.strokeStyle = 'rgba(0,0,0,.18)'; ctx.lineWidth = 2; ctx.strokeRect(1, 1, s - 2, s - 2);
  for (let i = 0; i < 40; i++) {
    const v = (Math.random() * 18 | 0) - 9;
    ctx.fillStyle = `rgba(${140 + v},${100 + v},${60 + v},.5)`;
    ctx.fillRect(Math.random() * s, Math.random() * s, 2, 2);
  }
}, 64, [8, 8]);

const TX_WOOD = makeTexture((ctx, s) => {
  ctx.fillStyle = '#8a5a30'; ctx.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y += 4) {
    ctx.fillStyle = (y % 8 === 0) ? '#6d4322' : '#9c6a3a';
    ctx.fillRect(0, y, s, 2);
  }
}, 64, [3, 1]);

const TX_WALL = makeTexture((ctx, s) => {
  ctx.fillStyle = '#e7dcc7'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 50; i++) {
    const v = (Math.random() * 10 | 0) - 5;
    ctx.fillStyle = `rgba(${210 + v},${196 + v},${170 + v},.6)`;
    ctx.fillRect(Math.random() * s, Math.random() * s, 3, 3);
  }
}, 64, [6, 2]);

// ══════════════════════════════════════════════════════════
// ESCENA / CÁMARA / RENDERER
// ══════════════════════════════════════════════════════════
const canvasEl = document.getElementById('scene');
const scene = new THREE.Scene(); // sin fondo -> deja ver el video de la cámara detrás

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.05, 60);

const renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.setClearColor(0x000000, 0); // transparente: se ve el video detrás
renderer.outputColorSpace = THREE.SRGBColorSpace;

window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

scene.add(new THREE.AmbientLight(0xfff2df, 0.55));
const keyLight = new THREE.DirectionalLight(0xfff2df, 0.9);
keyLight.position.set(3, 5, 2);
scene.add(keyLight);
const warmFillA = new THREE.PointLight(0xffb066, 1.2, 9);
warmFillA.position.set(-2.3, 2.4, -3.2);
scene.add(warmFillA);
const warmFillB = new THREE.PointLight(0xffe0a8, 0.9, 8);
warmFillB.position.set(1.2, 2.4, -3.2);
scene.add(warmFillB);

// ══════════════════════════════════════════════════════════
// DISTRIBUCIÓN DE LA COCINA (constantes de layout)
// ══════════════════════════════════════════════════════════
const ROOM_HALF = 4;        // el cuarto va de -4 a 4 en X y Z
const WALL_H = 3;
const BACK_WALL_Z = -ROOM_HALF;
const COUNTER_DEPTH = 0.7;
const COUNTER_TOP_Y = 0.95;
const PLAYER_EYE = 1.62;
const PLAYER_RADIUS = 0.3;
const STOVE_CX = -2.3;

// Puntos de interés (zonas) — se usan tanto para construir la
// geometría como para las comprobaciones de interacción, así
// que viven en un único lugar para no desincronizarse.
const ZONE = {
  stoveButton: { pos: new THREE.Vector3(STOVE_CX, 1.22, BACK_WALL_Z + COUNTER_DEPTH - 0.03), r: 0.16 },
  burners: [
    { pos: new THREE.Vector3(STOVE_CX - 0.45, COUNTER_TOP_Y, BACK_WALL_Z + 0.18), r: 0.24 }, // trasero-izq
    { pos: new THREE.Vector3(STOVE_CX + 0.45, COUNTER_TOP_Y, BACK_WALL_Z + 0.18), r: 0.24 }, // trasero-der
    { pos: new THREE.Vector3(STOVE_CX - 0.45, COUNTER_TOP_Y, BACK_WALL_Z + 0.5), r: 0.24 },  // frontal-izq
    { pos: new THREE.Vector3(STOVE_CX + 0.45, COUNTER_TOP_Y, BACK_WALL_Z + 0.5), r: 0.24 }   // frontal-der
  ],
  board: { pos: new THREE.Vector3(-0.4, COUNTER_TOP_Y, -3.55), r: 0.42 },
  assembly: { pos: new THREE.Vector3(1.1, COUNTER_TOP_Y, -3.55), r: 0.42 },
  plateStack: { pos: new THREE.Vector3(2.05, COUNTER_TOP_Y + 0.05, -3.6), r: 0.32 },
  pass: { pos: new THREE.Vector3(3.55, 1.05, 0.1), r: 0.48 },
  fridgeHandle: { pos: new THREE.Vector3(-3.35, 1.25, -1.3), r: 0.42 },
  entranceHandle: { pos: new THREE.Vector3(3.9, 1.2, -1.85), r: 0.4 },
  trash: { pos: new THREE.Vector3(3.35, 0.55, -2.4), r: 0.42 },
  pantrySlots: [
    { kind: 'tomato', pos: new THREE.Vector3(-3.62, 1.75, 0.5) },
    { kind: 'lettuce', pos: new THREE.Vector3(-3.62, 1.75, 1.3) },
    { kind: 'cheese', pos: new THREE.Vector3(-3.62, 1.75, 2.1) },
    { kind: 'meat', pos: new THREE.Vector3(-3.62, 1.15, 0.8) },
    { kind: 'bun', pos: new THREE.Vector3(-3.62, 1.15, 1.7) }
  ],
  utensilSlots: {
    knife: new THREE.Vector3(3.62, 1.42, 1.8),
    spatula: new THREE.Vector3(3.62, 1.42, 2.3),
    ladle: new THREE.Vector3(3.62, 1.42, 2.8)
  }
};

// ---------- Colisionadores simples (AABB en XZ) para caminar ----------
const colliders = [];
function addCollider(minX, maxX, minZ, maxZ) { colliders.push({ minX, maxX, minZ, maxZ }); }
addCollider(-3.65, 3.65, BACK_WALL_Z, BACK_WALL_Z + COUNTER_DEPTH); // mostrador continuo
addCollider(-4.0, -3.15, -2.05, -0.55);                            // refrigerador
addCollider(-4.0, -3.5, 0.15, 2.45);                               // despensa
addCollider(3.15, 4.0, -0.85, 0.85);                               // ventanilla de servicio
addCollider(3.5, 4.0, 1.25, 3.35);                                 // estante de utensilios
addCollider(3.05, 3.65, -2.7, -2.1);                                // caneca de basura
addCollider(2.65, 3.35, 2.85, 3.55);                                // silla

function resolvePlayerXZ(newX, newZ) {
  let x = newX, z = newZ;
  const r = PLAYER_RADIUS;
  for (const c of colliders) {
    if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) {
      const penLeft = x - (c.minX - r);
      const penRight = (c.maxX + r) - x;
      const penTop = z - (c.minZ - r);
      const penBot = (c.maxZ + r) - z;
      const minPen = Math.min(penLeft, penRight, penTop, penBot);
      if (minPen === penLeft) x = c.minX - r;
      else if (minPen === penRight) x = c.maxX + r;
      else if (minPen === penTop) z = c.minZ - r;
      else z = c.maxZ + r;
    }
  }
  const bound = ROOM_HALF - 0.15;
  x = clamp(x, -bound, bound);
  z = clamp(z, -bound, bound);
  return { x, z };
}

// ══════════════════════════════════════════════════════════
// INGREDIENTES, UTENSILIOS, SARTENES Y PLATOS
// (definido ANTES de construir el entorno porque la despensa,
//  el estante y la estufa usan estos constructores para sus
//  marcas visuales y objetos iniciales)
// ══════════════════════════════════════════════════════════
const INGREDIENT_DEF = {
  tomato: { label: 'Tomate', color: 0xd1372b, needsChop: true, needsCook: false },
  lettuce: { label: 'Lechuga', color: 0x5fae3d, needsChop: true, needsCook: false },
  cheese: { label: 'Queso', color: 0xf5c542, needsChop: false, needsCook: false },
  bun: { label: 'Pan', color: 0xd9a55b, needsChop: false, needsCook: false },
  meat: { label: 'Carne', color: 0xc98169, needsChop: false, needsCook: true }
};

function buildIngredientMesh(kind, state) {
  const def = INGREDIENT_DEF[kind];
  const group = new THREE.Group();

  if (kind === 'meat') {
    const color = state === 'cooked' ? 0x6b3a22 : def.color;
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.8 });
    group.add(new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.09, 0.045, 16), mat));
  } else if (kind === 'bun') {
    const mat = new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.8 });
    const top = new THREE.Mesh(new THREE.SphereGeometry(0.095, 14, 10, 0, Math.PI * 2, 0, Math.PI / 1.7), mat);
    top.position.y = 0.01;
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.09, 0.035, 16), mat);
    base.position.y = -0.02;
    group.add(top, base);
  } else if (kind === 'cheese') {
    const mat = new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.5 });
    group.add(new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.028, 0.13), mat));
  } else { // tomato / lettuce
    const mat = new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.6 });
    if (state === 'chopped') {
      for (let i = 0; i < 5; i++) {
        const piece = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.02, 0.035), mat);
        piece.position.set(rand(-0.05, 0.05), 0.01, rand(-0.05, 0.05));
        piece.rotation.y = rand(0, Math.PI);
        group.add(piece);
      }
    } else {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.09, 14, 10), mat);
      mesh.scale.y = kind === 'lettuce' ? 0.75 : 0.9;
      group.add(mesh);
    }
  }
  group.userData.kind = kind;
  return group;
}

const ingredients = [];
const plates = [];

function spawnIngredient(kind, worldPos) {
  const mesh = buildIngredientMesh(kind, 'raw');
  mesh.position.copy(worldPos);
  scene.add(mesh);
  const obj = {
    kind: 'ingredient',
    ingredientType: kind,
    state: 'raw',
    choppedHits: 0,
    cookProgress: 0,
    mesh,
    heldBy: null,
    onBoard: false,
    inPan: false,
    grabOffset: new THREE.Vector3(),
    radius: 0.2
  };
  ingredients.push(obj);
  return obj;
}

function setIngredientState(obj, newState) {
  obj.state = newState;
  const pos = obj.mesh.position.clone();
  const parent = obj.mesh.parent;
  parent.remove(obj.mesh);
  obj.mesh = buildIngredientMesh(obj.ingredientType, newState);
  obj.mesh.position.copy(pos);
  parent.add(obj.mesh);
}

function isIngredientReady(obj) {
  const def = INGREDIENT_DEF[obj.ingredientType];
  if (def.needsChop && obj.state !== 'chopped') return false;
  if (def.needsCook && obj.state !== 'cooked') return false;
  return true;
}

// ---------- Sartenes (2 unidades, se pueden mover entre los 4 fogones) ----------
function buildPanMesh() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.35, metalness: 0.6 });
  group.add(new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.2, 0.055, 20), mat));
  const handle = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.03, 0.05), new THREE.MeshStandardMaterial({ color: 0x1c1c1c, roughness: 0.6 }));
  handle.position.set(0.34, 0, 0);
  group.add(handle);
  return group;
}
const pans = [2, 3].map(burnerIdx => {
  const b = ZONE.burners[burnerIdx];
  const mesh = buildPanMesh();
  mesh.position.set(b.pos.x, b.pos.y + 0.03, b.pos.z);
  scene.add(mesh);
  return { kind: 'pan', mesh, heldBy: null, onStove: true, contents: [], grabOffset: new THREE.Vector3(), radius: 0.3 };
});

// ---------- Platos ----------
function buildPlateMesh() {
  const group = new THREE.Group();
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.205, 0.018, 24), new THREE.MeshStandardMaterial({ color: 0xf2ede0, roughness: 0.35 }));
  group.add(rim);
  const inner = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.006, 24), new THREE.MeshStandardMaterial({ color: 0xe4ddcb, roughness: 0.4 }));
  inner.position.y = 0.011;
  group.add(inner);
  return group;
}
function spawnPlate(worldPos) {
  const mesh = buildPlateMesh();
  mesh.position.copy(worldPos);
  scene.add(mesh);
  const obj = { kind: 'plate', mesh, heldBy: null, contents: [], grabOffset: new THREE.Vector3(), radius: 0.28 };
  plates.push(obj);
  return obj;
}
// Pila decorativa de platos (marca visual del punto de suministro)
for (let i = 0; i < 4; i++) {
  const deco = buildPlateMesh();
  deco.position.set(ZONE.plateStack.pos.x, ZONE.plateStack.pos.y - 0.05 + i * 0.02, ZONE.plateStack.pos.z);
  scene.add(deco);
}

// ---------- Utensilios (cuchillo, espátula, cucharón) ----------
function buildKnifeMesh() {
  const group = new THREE.Group();
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.02, 0.045), new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.25, metalness: 0.8 }));
  blade.position.x = 0.11;
  const handle = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.028, 0.03), new THREE.MeshStandardMaterial({ color: 0x2a1c10, roughness: 0.6 }));
  handle.position.x = -0.06;
  group.add(blade, handle);
  return group;
}
function buildSpatulaMesh() {
  const group = new THREE.Group();
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.24, 8), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.5 }));
  handle.rotation.z = Math.PI / 2;
  handle.position.x = -0.02;
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.006, 0.07), new THREE.MeshStandardMaterial({ color: 0xcccccc, roughness: 0.35, metalness: 0.5 }));
  head.position.x = 0.14;
  group.add(handle, head);
  return group;
}
function buildLadleMesh() {
  const group = new THREE.Group();
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.26, 8), new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.4, metalness: 0.6 }));
  handle.rotation.z = Math.PI / 2;
  handle.position.x = -0.03;
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8, 0, Math.PI * 2, 0, Math.PI / 1.8), new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.3, metalness: 0.6 }));
  bowl.rotation.x = Math.PI;
  bowl.position.x = 0.14;
  group.add(handle, bowl);
  return group;
}

const utensils = [];
function makeUtensil(toolType, mesh, pos, radius) {
  mesh.rotation.y = Math.PI / 2; // acostado en paralelo al estante
  mesh.position.copy(pos);
  scene.add(mesh);
  const obj = { kind: 'utensil', toolType, mesh, heldBy: null, grabOffset: new THREE.Vector3(), radius };
  utensils.push(obj);
  return obj;
}
const knife = makeUtensil('knife', buildKnifeMesh(), ZONE.utensilSlots.knife, 0.22);
const spatula = makeUtensil('spatula', buildSpatulaMesh(), ZONE.utensilSlots.spatula, 0.22);
const ladle = makeUtensil('ladle', buildLadleMesh(), ZONE.utensilSlots.ladle, 0.22);

// ══════════════════════════════════════════════════════════
// CONSTRUCCIÓN DEL ENTORNO (piso, paredes, mobiliario)
// ══════════════════════════════════════════════════════════
function buildBox(w, h, d, cx, cy, cz, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(cx, cy, cz);
  scene.add(mesh);
  return mesh;
}

// Estante abierto contra una pared vertical (a lo largo del eje Z).
// `dir` = +1 si el estante sobresale hacia +X (pared izquierda),
//         -1 si sobresale hacia -X (pared derecha).
function buildShelfUnitZ(x, z0, z1, height, depth, tiers, dir) {
  const frameMat = new THREE.MeshStandardMaterial({ map: TX_WOOD, roughness: 0.7 });
  const length = Math.abs(z1 - z0);
  const cz = (z0 + z1) / 2;
  [z0, z1].forEach(z => {
    const side = new THREE.Mesh(new THREE.BoxGeometry(depth, height, 0.04), frameMat);
    side.position.set(x + dir * depth / 2, height / 2, z);
    scene.add(side);
  });
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.03, height, length), frameMat);
  back.position.set(x + dir * 0.015, height / 2, cz);
  scene.add(back);
  tiers.forEach(y => {
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(depth, 0.03, length), frameMat);
    shelf.position.set(x + dir * depth / 2, y, cz);
    scene.add(shelf);
  });
}

const counterMat = new THREE.MeshStandardMaterial({ map: TX_WOOD, roughness: 0.75 });
const metalMat = new THREE.MeshStandardMaterial({ color: 0x585858, roughness: 0.35, metalness: 0.6 });
const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf3f0e6, roughness: 0.55 });

// ---------- Piso, paredes y techo ----------
(function buildShell() {
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(ROOM_HALF * 2, ROOM_HALF * 2),
    new THREE.MeshStandardMaterial({ map: TX_FLOOR, roughness: 0.9 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const wallMat = new THREE.MeshStandardMaterial({ map: TX_WALL, roughness: 0.95, side: THREE.DoubleSide });
  function wall(cx, cz, rotY) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(ROOM_HALF * 2, WALL_H), wallMat);
    m.position.set(cx, WALL_H / 2, cz);
    m.rotation.y = rotY;
    scene.add(m);
  }
  wall(0, BACK_WALL_Z, 0);
  wall(0, ROOM_HALF, Math.PI);
  wall(-ROOM_HALF, 0, Math.PI / 2);
  wall(ROOM_HALF, 0, -Math.PI / 2);

  const ceiling = new THREE.Mesh(
    new THREE.PlaneGeometry(ROOM_HALF * 2, ROOM_HALF * 2),
    new THREE.MeshStandardMaterial({ color: 0x2a2016, roughness: 1, side: THREE.DoubleSide })
  );
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.y = WALL_H;
  scene.add(ceiling);

  // Ventana decorativa en la pared frontal (solo ambiente, luz cálida)
  const win = new THREE.Mesh(
    new THREE.PlaneGeometry(1.4, 1.0),
    new THREE.MeshStandardMaterial({ color: 0xbfe3ff, emissive: 0x88bfe0, emissiveIntensity: 0.5 })
  );
  win.position.set(-2.4, 1.9, ROOM_HALF - 0.02);
  win.rotation.y = Math.PI;
  scene.add(win);

  // Letrero "COCINA"
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.6), new THREE.MeshBasicMaterial({ map: makeTextPanel('COCINA', 'Restaurante VR'), transparent: true }));
  sign.position.set(0, 2.55, BACK_WALL_Z + 0.02);
  scene.add(sign);

  // Lámparas colgantes sobre la línea de cocina
  [STOVE_CX, 1.1].forEach(x => {
    const cordMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a });
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.7, 6), cordMat);
    cord.position.set(x, 2.65, -3.5);
    scene.add(cord);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.2, 16, 1, true),
      new THREE.MeshStandardMaterial({ color: 0x402a18, side: THREE.DoubleSide, roughness: 0.6 }));
    shade.position.set(x, 2.3, -3.5);
    scene.add(shade);
    const bulb = new THREE.PointLight(0xffd9a0, 0.9, 6);
    bulb.position.set(x, 2.2, -3.5);
    scene.add(bulb);
  });
})();

// ---------- Mostrador principal ----------
const counterCX = 0, counterCZ = BACK_WALL_Z + COUNTER_DEPTH / 2;
buildBox(7.3, COUNTER_TOP_Y, COUNTER_DEPTH, counterCX, COUNTER_TOP_Y / 2, counterCZ, counterMat);

// ---------- Estufa detallada: cuerpo, 4 fogones, botón único, campana ----------
buildBox(2.0, 0.1, COUNTER_DEPTH * 0.95, STOVE_CX, COUNTER_TOP_Y + 0.03, counterCZ, metalMat);

const burnerRingMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.5, metalness: 0.3 });
ZONE.burners.forEach(b => {
  const outer = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.018, 8, 20), burnerRingMat);
  outer.rotation.x = Math.PI / 2;
  outer.position.set(b.pos.x, COUNTER_TOP_Y + 0.09, b.pos.z);
  scene.add(outer);
  const inner = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.012, 6, 16), burnerRingMat);
  inner.rotation.x = Math.PI / 2;
  inner.position.set(b.pos.x, COUNTER_TOP_Y + 0.09, b.pos.z);
  scene.add(inner);
  for (let i = 0; i < 6; i++) {
    const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.012, 0.012), burnerRingMat);
    spoke.position.set(b.pos.x, COUNTER_TOP_Y + 0.095, b.pos.z);
    spoke.rotation.y = (i / 6) * Math.PI;
    scene.add(spoke);
  }
});

// Panel de control frontal con el botón único de encendido
buildBox(2.0, 0.16, 0.05, STOVE_CX, COUNTER_TOP_Y + 0.16, BACK_WALL_Z + COUNTER_DEPTH - 0.025,
  new THREE.MeshStandardMaterial({ color: 0x2c2c2c, roughness: 0.4, metalness: 0.5 }));

const buttonSocket = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.02, 16), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.5 }));
buttonSocket.rotation.x = Math.PI / 2;
buttonSocket.position.copy(ZONE.stoveButton.pos).add(new THREE.Vector3(0, 0, -0.015));
scene.add(buttonSocket);

const stoveButtonMat = new THREE.MeshStandardMaterial({ color: 0xcc2222, emissive: 0x000000, emissiveIntensity: 0, roughness: 0.35 });
const stoveButtonMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.038, 0.025, 16), stoveButtonMat);
stoveButtonMesh.rotation.x = Math.PI / 2;
stoveButtonMesh.position.copy(ZONE.stoveButton.pos);
scene.add(stoveButtonMesh);
const powerLabel = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.08), new THREE.MeshBasicMaterial({ map: makeTextPanel('ON/OFF', '', 220, 100), transparent: true }));
powerLabel.position.copy(ZONE.stoveButton.pos).add(new THREE.Vector3(0, -0.11, -0.02));
scene.add(powerLabel);

// Llamas de los 4 fogones (ocultas hasta encender la estufa)
const flameMat = new THREE.MeshStandardMaterial({ color: 0xff7b1a, emissive: 0xff5500, emissiveIntensity: 1.4, transparent: true, opacity: 0.85 });
const flames = ZONE.burners.map(b => {
  const g = new THREE.Group();
  for (let i = 0; i < 3; i++) {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.05 - i * 0.008, 0.14 - i * 0.02, 8), flameMat);
    cone.position.y = i * 0.01;
    cone.rotation.y = i;
    g.add(cone);
  }
  g.position.set(b.pos.x, COUNTER_TOP_Y + 0.14, b.pos.z);
  g.visible = false;
  scene.add(g);
  return g;
});

// Campana extractora (detalle sobre la estufa)
const hoodMat = new THREE.MeshStandardMaterial({ color: 0x666666, roughness: 0.4, metalness: 0.6 });
buildBox(2.1, 0.5, 0.55, STOVE_CX, 2.55, BACK_WALL_Z + 0.35, hoodMat);
const hoodPipe = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.2, 12), hoodMat);
hoodPipe.position.set(STOVE_CX, 2.9, BACK_WALL_Z + 0.35);
scene.add(hoodPipe);
const hoodLight = new THREE.PointLight(0xfff0d0, 1.1, 4);
hoodLight.position.set(STOVE_CX, 2.25, -3.6);
scene.add(hoodLight);

// ---------- Tabla de picar ----------
const boardMesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.03, 0.36), new THREE.MeshStandardMaterial({ map: TX_WOOD, roughness: 0.6 }));
boardMesh.position.set(ZONE.board.pos.x, COUNTER_TOP_Y + 0.016, ZONE.board.pos.z);
scene.add(boardMesh);

// Marca del mostrador de armado (círculo pintado, puramente visual)
const assemblyMark = new THREE.Mesh(new THREE.RingGeometry(0.28, 0.32, 24), new THREE.MeshBasicMaterial({ color: 0xffcc88, side: THREE.DoubleSide }));
assemblyMark.rotation.x = -Math.PI / 2;
assemblyMark.position.set(ZONE.assembly.pos.x, COUNTER_TOP_Y + 0.012, ZONE.assembly.pos.z);
scene.add(assemblyMark);

// ---------- Refrigerador (pared izquierda) ----------
const fridgeBody = buildBox(0.7, 2.1, 1.5, -3.65, 1.05, -1.3, whiteMat);
const fridgeDoorGeo = new THREE.BoxGeometry(0.62, 1.95, 0.06);
fridgeDoorGeo.translate(0, 0, 0.62 / 2); // pivote en el borde (bisagra)
const fridgeDoorMesh = new THREE.Mesh(fridgeDoorGeo, new THREE.MeshStandardMaterial({ color: 0xe8e4d8, roughness: 0.4, metalness: 0.15 }));
fridgeDoorMesh.position.set(-3.28, 1.05, -2.02);
scene.add(fridgeDoorMesh);
const fridgeHandleMesh = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.35, 0.03), new THREE.MeshStandardMaterial({ color: 0x999999, metalness: 0.6, roughness: 0.3 }));
fridgeHandleMesh.position.set(0.05, 0, 0.55);
fridgeDoorMesh.add(fridgeHandleMesh);

// Un par de bebidas decorativas dentro (solo visibles con la puerta abierta)
const fridgeBottles = [0xdc3545, 0x1e88e5].map((color, i) => {
  const bottle = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.22, 12),
    new THREE.MeshStandardMaterial({ color, roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 }));
  bottle.add(body);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.03, 8), new THREE.MeshStandardMaterial({ color: 0x333333 }));
  cap.position.y = 0.125;
  bottle.add(cap);
  bottle.position.set(-3.5, 1.35 - i * 0.02, -1.7 + i * 0.5);
  bottle.visible = false;
  scene.add(bottle);
  return bottle;
});

// ---------- Despensa (pared izquierda) — alimentos siempre visibles, sin puerta ----------
buildShelfUnitZ(-4, 0.2, 2.4, 2.0, 0.45, [0.6, 1.2, 1.85], 1);
ZONE.pantrySlots.forEach(slot => {
  const marker = buildIngredientMesh(slot.kind, 'raw');
  marker.scale.setScalar(1.15);
  marker.position.copy(slot.pos);
  scene.add(marker);
  const basket = new THREE.Mesh(
    new THREE.CylinderGeometry(0.13, 0.11, 0.08, 16, 1, true),
    new THREE.MeshStandardMaterial({ color: 0xb08050, roughness: 0.85, side: THREE.DoubleSide })
  );
  basket.position.set(slot.pos.x, slot.pos.y - 0.055, slot.pos.z);
  scene.add(basket);
  const label = new THREE.Mesh(
    new THREE.PlaneGeometry(0.24, 0.09),
    new THREE.MeshBasicMaterial({ map: makeTextPanel(INGREDIENT_DEF[slot.kind].label, '', 300, 110), transparent: true })
  );
  label.position.set(slot.pos.x + 0.06, slot.pos.y - 0.14, slot.pos.z);
  label.rotation.y = Math.PI / 2;
  scene.add(label);
});
const pantrySign = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.3), new THREE.MeshBasicMaterial({ map: makeTextPanel('DESPENSA', '', 360, 120), transparent: true }));
pantrySign.position.set(-3.55, 2.15, 1.3);
pantrySign.rotation.y = Math.PI / 2;
scene.add(pantrySign);

// ---------- Ventanilla de servicio (pared derecha) ----------
buildBox(0.5, 0.9, 1.7, 3.75, 0.45, 0.1, counterMat);
const passOpening = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.1), new THREE.MeshStandardMaterial({ color: 0xffdca0, emissive: 0xffb060, emissiveIntensity: 0.6 }));
passOpening.rotation.y = -Math.PI / 2;
passOpening.position.set(ROOM_HALF - 0.02, 1.5, 0.1);
scene.add(passOpening);
const passSign = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.4), new THREE.MeshBasicMaterial({ map: makeTextPanel('PASE', 'entrega aquí'), transparent: true }));
passSign.rotation.y = -Math.PI / 2;
passSign.position.set(ROOM_HALF - 0.03, 2.05, 0.1);
scene.add(passSign);

// ---------- Puerta doble de entrada (decorativa, pared derecha) ----------
const doorMat = new THREE.MeshStandardMaterial({ map: TX_WOOD, roughness: 0.7 });
const doorLGeo = new THREE.BoxGeometry(0.5, 1.9, 0.05); doorLGeo.translate(0, 0, -0.25);
const doorRGeo = new THREE.BoxGeometry(0.5, 1.9, 0.05); doorRGeo.translate(0, 0, 0.25);
const entranceDoorL = new THREE.Mesh(doorLGeo, doorMat);
const entranceDoorR = new THREE.Mesh(doorRGeo, doorMat);
entranceDoorL.position.set(ROOM_HALF - 0.03, 1.05, -1.85);
entranceDoorR.position.set(ROOM_HALF - 0.03, 1.05, -1.85);
scene.add(entranceDoorL, entranceDoorR);

// ---------- Estante de utensilios (pared derecha) ----------
buildShelfUnitZ(4, 1.3, 3.3, 2.0, 0.45, [0.6, 1.35], -1);
[
  { name: 'CUCHILLO', pos: ZONE.utensilSlots.knife },
  { name: 'ESPÁTULA', pos: ZONE.utensilSlots.spatula },
  { name: 'CUCHARÓN', pos: ZONE.utensilSlots.ladle }
].forEach(u => {
  const label = new THREE.Mesh(
    new THREE.PlaneGeometry(0.24, 0.09),
    new THREE.MeshBasicMaterial({ map: makeTextPanel(u.name, '', 300, 110), transparent: true })
  );
  label.position.set(u.pos.x - 0.06, u.pos.y - 0.18, u.pos.z);
  label.rotation.y = -Math.PI / 2;
  scene.add(label);
});
const utensilSign = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.3), new THREE.MeshBasicMaterial({ map: makeTextPanel('UTENSILIOS', '', 360, 120), transparent: true }));
utensilSign.position.set(3.55, 2.15, 2.3);
utensilSign.rotation.y = -Math.PI / 2;
scene.add(utensilSign);

// ---------- Caneca de basura ----------
(function buildTrashCan() {
  const group = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.22, 0.55, 16), new THREE.MeshStandardMaterial({ color: 0x37474f, roughness: 0.55, metalness: 0.3 }));
  body.position.y = 0.275;
  group.add(body);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.02, 8, 16), new THREE.MeshStandardMaterial({ color: 0x263238, roughness: 0.4, metalness: 0.4 }));
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.55;
  group.add(rim);
  const label = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.1), new THREE.MeshBasicMaterial({ color: 0x90a4ae }));
  label.position.set(0, 0.3, 0.23);
  group.add(label);
  group.position.set(ZONE.trash.pos.x, 0, ZONE.trash.pos.z);
  scene.add(group);
})();

// ---------- Silla (decorativa) ----------
(function buildChair() {
  const group = new THREE.Group();
  const woodMat = new THREE.MeshStandardMaterial({ map: TX_WOOD, roughness: 0.7 });
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.05, 0.42), woodMat);
  seat.position.y = 0.46;
  group.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.5, 0.05), woodMat);
  back.position.set(0, 0.71, -0.19);
  group.add(back);
  const legGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.46, 8);
  [[-0.17, -0.17], [0.17, -0.17], [-0.17, 0.17], [0.17, 0.17]].forEach(([x, z]) => {
    const leg = new THREE.Mesh(legGeo, woodMat);
    leg.position.set(x, 0.23, z);
    group.add(leg);
  });
  group.position.set(3.0, 0, 3.2);
  group.rotation.y = -0.5;
  scene.add(group);
})();

// ══════════════════════════════════════════════════════════
// MANOS 3D (avatar de las manos rastreadas)
// Silueta con palma ovalada orientable + dedos cónicos + puntas
// redondeadas, en tono piel, para que se vea como una mano real
// en vez de un esqueleto de líneas.
// ══════════════════════════════════════════════════════════
const FINGER_SEGMENTS = [
  [1, 2], [2, 3], [3, 4],
  [5, 6], [6, 7], [7, 8],
  [9, 10], [10, 11], [11, 12],
  [13, 14], [14, 15], [15, 16],
  [17, 18], [18, 19], [19, 20]
];
const FINGER_NAMES = ['thumb', 'index', 'middle', 'ring', 'pinky'];
// Radios [base, nudillo1, nudillo2, punta] por dedo — dan el efecto cónico
const FINGER_RADII = {
  thumb: [0.021, 0.018, 0.015, 0.012],
  index: [0.018, 0.016, 0.013, 0.010],
  middle: [0.019, 0.017, 0.014, 0.011],
  ring: [0.017, 0.015, 0.012, 0.010],
  pinky: [0.015, 0.013, 0.011, 0.009]
};
const HAND_ACCENT = { left: 0x4fc3f7, right: 0xffb74d };
const SKIN_COLOR = 0xe3a97a;
const _UP = new THREE.Vector3(0, 1, 0);

function buildHandVisual(handKey) {
  const root = new THREE.Group();
  const skinMat = new THREE.MeshStandardMaterial({ color: SKIN_COLOR, roughness: 0.55, emissive: 0x552200, emissiveIntensity: 0 });

  // Palma: elipsoide (esfera unitaria escalada y orientada cada frame)
  const palm = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 14), skinMat);
  root.add(palm);

  // Muñequera de color para distinguir izquierda/derecha de un vistazo
  const wrist = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.01, 8, 16),
    new THREE.MeshStandardMaterial({ color: HAND_ACCENT[handKey], roughness: 0.4, metalness: 0.3 }));
  root.add(wrist);

  // Segmentos de dedos: cilindros cónicos (más gruesos cerca de la palma)
  const segs = FINGER_SEGMENTS.map(([a, b], i) => {
    const finger = FINGER_NAMES[Math.floor(i / 3)];
    const k = i % 3;
    const radii = FINGER_RADII[finger];
    const geo = new THREE.CylinderGeometry(radii[k + 1], radii[k], 1, 8);
    const mesh = new THREE.Mesh(geo, skinMat);
    root.add(mesh);
    return { mesh, a, b };
  });

  // Puntas de los dedos: pequeñas esferas para un remate redondeado
  const tips = FINGER_NAMES.map(finger => {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(FINGER_RADII[finger][3], 8, 8), skinMat);
    root.add(mesh);
    return mesh;
  });

  root.visible = false;
  scene.add(root);
  return { root, palm, wrist, skinMat, segs, tips };
}
const handVisuals = { left: buildHandVisual('left'), right: buildHandVisual('right') };

// ---------- Mapeo de coordenadas de la mano (0..1 de MediaPipe) a espacio 3D ----------
// Las manos se ubican SIEMPRE relativas a la cámara (como si el jugador las
// extendiera frente a su pecho), por lo que se mueven junto con él al caminar.
const HAND_SPACE = { width: 1.7, height: 1.3, vOffset: -0.12, depthBase: 0.55, depthScale: 1.6 };
const _localOffset = new THREE.Vector3();
function handWorldPosition(nx, ny, nz, out) {
  const depth = clamp(HAND_SPACE.depthBase - nz * HAND_SPACE.depthScale, 0.28, 1.7);
  _localOffset.set(
    (nx - 0.5) * HAND_SPACE.width,
    (0.5 - ny) * HAND_SPACE.height + HAND_SPACE.vOffset,
    -depth
  );
  out.copy(_localOffset).applyMatrix4(camera.matrixWorld);
  return out;
}

const _tmpA = new THREE.Vector3(), _tmpB = new THREE.Vector3(), _tmpPalm = new THREE.Vector3();
const _pR = new THREE.Vector3(), _pF = new THREE.Vector3(), _pU = new THREE.Vector3();
const _wristW = new THREE.Vector3(), _idxBaseW = new THREE.Vector3(), _pinkyBaseW = new THREE.Vector3(), _midBaseW = new THREE.Vector3();
const _basisMat = new THREE.Matrix4();

function updateHandVisuals() {
  for (const handKey of ['left', 'right']) {
    const h = HandTracking.hands[handKey];
    const vis = handVisuals[handKey];
    vis.root.visible = h.detected;
    if (!h.detected || !h.landmarks) continue;

    vis.skinMat.emissiveIntensity = h.isPinching ? 0.8 : 0;

    const lm = h.landmarks;
    handWorldPosition(lm[0].x, lm[0].y, lm[0].z, _wristW);
    handWorldPosition(lm[5].x, lm[5].y, lm[5].z, _idxBaseW);
    handWorldPosition(lm[17].x, lm[17].y, lm[17].z, _pinkyBaseW);
    handWorldPosition(lm[9].x, lm[9].y, lm[9].z, _midBaseW);

    // Base ortonormal de la palma: ancho (nudillos), adelante (muñeca->dedos), normal
    _pR.copy(_idxBaseW).sub(_pinkyBaseW).normalize();
    _pF.copy(_midBaseW).sub(_wristW).normalize();
    _pU.crossVectors(_pR, _pF).normalize();
    _pF.crossVectors(_pU, _pR).normalize();
    _basisMat.makeBasis(_pR, _pU, _pF);
    vis.palm.quaternion.setFromRotationMatrix(_basisMat);
    vis.wrist.quaternion.copy(vis.palm.quaternion);

    handWorldPosition(h.palm.x, h.palm.y, h.palm.z, vis.palm.position);
    const width = _idxBaseW.distanceTo(_pinkyBaseW) * 1.2 + 0.01;
    const length = _wristW.distanceTo(_midBaseW) * 1.05 + 0.01;
    vis.palm.scale.set(width * 0.5, width * 0.28, length * 0.55);
    vis.wrist.position.copy(_wristW);

    for (const seg of vis.segs) {
      const a = lm[seg.a], b = lm[seg.b];
      const pa = handWorldPosition(a.x, a.y, a.z, _tmpA).clone();
      const pb = handWorldPosition(b.x, b.y, b.z, _tmpB).clone();
      const mid = pa.clone().add(pb).multiplyScalar(0.5);
      const dir = pb.clone().sub(pa);
      const len = dir.length() || 0.001;
      dir.normalize();
      seg.mesh.position.copy(mid);
      seg.mesh.scale.set(1, len, 1);
      seg.mesh.quaternion.setFromUnitVectors(_UP, dir);
    }

    for (let f = 0; f < 5; f++) {
      const tipIdx = FINGER_SEGMENTS[f * 3 + 2][1];
      const p = lm[tipIdx];
      handWorldPosition(p.x, p.y, p.z, vis.tips[f].position);
    }
  }
}

// ══════════════════════════════════════════════════════════
// INTERACCIÓN: agarrar, soltar, picar, remover, cocinar, servir
// ══════════════════════════════════════════════════════════
const activeGrab = { left: null, right: null };
let stoveOn = false;
let fridgeOpen = false;
let entranceOpen = false;

function allGrabbables() { return [...ingredients, ...pans, ...plates, ...utensils]; }

function nearestGrabbable(worldPos) {
  let best = null, bestD = Infinity;
  for (const obj of allGrabbables()) {
    if (obj.heldBy) continue;
    if (obj.onBoard) {
      const def = obj.ingredientType && INGREDIENT_DEF[obj.ingredientType];
      if (def && def.needsChop && obj.state === 'raw') continue; // primero hay que picarlo
    }
    const d = obj.mesh.position.distanceTo(worldPos);
    if (d < obj.radius && d < bestD) { bestD = d; best = obj; }
  }
  return best;
}

function detachFromPan(obj) {
  for (const p of pans) {
    if (obj.mesh.parent === p.mesh) {
      const worldPos = new THREE.Vector3();
      obj.mesh.getWorldPosition(worldPos);
      p.mesh.remove(obj.mesh);
      scene.add(obj.mesh);
      obj.mesh.position.copy(worldPos);
      obj.mesh.rotation.set(0, 0, 0);
      const i = p.contents.indexOf(obj);
      if (i !== -1) p.contents.splice(i, 1);
      break;
    }
  }
  obj.inPan = false;
}

function grabObject(handKey, obj, worldPos) {
  detachFromPan(obj);
  obj.heldBy = handKey;
  obj.onBoard = false;
  if (obj.onStove !== undefined) obj.onStove = false;
  obj.grabOffset.copy(obj.mesh.position).sub(worldPos);
  activeGrab[handKey] = obj;
}

function toggleStove() {
  stoveOn = !stoveOn;
  stoveButtonMat.color.set(stoveOn ? 0x2ecc71 : 0xcc2222);
  stoveButtonMat.emissive.set(stoveOn ? 0x2ecc71 : 0x000000);
  stoveButtonMat.emissiveIntensity = stoveOn ? 0.8 : 0;
  const el = document.getElementById('stove-state');
  el.textContent = stoveOn ? 'Encendida' : 'Apagada';
  el.classList.toggle('on', stoveOn);
  showToast(stoveOn ? '🔥 Estufa encendida (4 fogones)' : '🔥 Estufa apagada');
}
function toggleFridge() {
  fridgeOpen = !fridgeOpen;
  showToast(fridgeOpen ? '🚪 Refrigerador abierto' : '🚪 Refrigerador cerrado');
}
function toggleEntranceDoor() {
  entranceOpen = !entranceOpen;
  showToast(entranceOpen ? '🚪 Puerta abierta' : '🚪 Puerta cerrada');
}

function handleGrabStart(handKey, worldPos) {
  if (worldPos.distanceTo(ZONE.stoveButton.pos) < ZONE.stoveButton.r) { toggleStove(); return; }
  if (worldPos.distanceTo(ZONE.fridgeHandle.pos) < ZONE.fridgeHandle.r) { toggleFridge(); return; }
  if (worldPos.distanceTo(ZONE.entranceHandle.pos) < ZONE.entranceHandle.r) { toggleEntranceDoor(); return; }

  for (const slot of ZONE.pantrySlots) {
    if (worldPos.distanceTo(slot.pos) < 0.24) {
      const obj = spawnIngredient(slot.kind, slot.pos.clone());
      grabObject(handKey, obj, worldPos);
      return;
    }
  }
  if (worldPos.distanceTo(ZONE.plateStack.pos) < ZONE.plateStack.r) {
    const obj = spawnPlate(ZONE.plateStack.pos.clone());
    grabObject(handKey, obj, worldPos);
    return;
  }

  const obj = nearestGrabbable(worldPos);
  if (obj) grabObject(handKey, obj, worldPos);
}

function surfaceYAt(x, z) {
  if (z < -3.2 && x > -3.6 && x < 3.6) return COUNTER_TOP_Y; // sobre el mostrador
  if (x > 3.15 && z > -0.85 && z < 0.85) return 0.9;         // sobre la ventanilla
  return 0; // piso
}
function settleOnSurface(obj) {
  obj.mesh.position.y = surfaceYAt(obj.mesh.position.x, obj.mesh.position.z) + 0.05;
}

function nearestPlateWithin(worldPos, maxDist) {
  let best = null, bestD = Infinity;
  for (const p of plates) {
    const d = p.mesh.position.distanceTo(worldPos);
    if (d < maxDist && d < bestD) { bestD = d; best = p; }
  }
  return best;
}
function findNearbyPan(worldPos, maxDist) {
  let best = null, bestD = Infinity;
  for (const p of pans) {
    if (!p.onStove) continue;
    const d = p.mesh.position.distanceTo(worldPos);
    if (d < maxDist && d < bestD) { bestD = d; best = p; }
  }
  return best;
}

function addIngredientToPlate(plate, obj) {
  detachFromPan(obj);
  plate.contents.push({ kind: obj.ingredientType, state: obj.state });
  scene.remove(obj.mesh);
  const i = ingredients.indexOf(obj);
  if (i !== -1) ingredients.splice(i, 1);

  const topping = buildIngredientMesh(obj.ingredientType, obj.state);
  topping.scale.setScalar(0.85);
  topping.position.set(rand(-0.05, 0.05), 0.015 + plate.contents.length * 0.02, rand(-0.05, 0.05));
  plate.mesh.add(topping);
  showToast(`✅ ${INGREDIENT_DEF[obj.ingredientType].label} agregado al plato`);
}

function releaseIngredient(obj, worldPos) {
  if (worldPos.distanceTo(ZONE.trash.pos) < ZONE.trash.r) {
    scene.remove(obj.mesh);
    const i = ingredients.indexOf(obj);
    if (i !== -1) ingredients.splice(i, 1);
    showToast('🗑 Ingrediente descartado');
    return;
  }
  const plate = nearestPlateWithin(worldPos, 0.32);
  if (plate) {
    if (isIngredientReady(obj)) { addIngredientToPlate(plate, obj); return; }
    showToast(`⚠ Prepara primero el ${INGREDIENT_DEF[obj.ingredientType].label.toLowerCase()}`);
  }
  if (worldPos.distanceTo(ZONE.board.pos) < ZONE.board.r) {
    obj.mesh.position.set(worldPos.x, COUNTER_TOP_Y + 0.05, worldPos.z);
    obj.onBoard = true;
    return;
  }
  const targetPan = findNearbyPan(worldPos, 0.26);
  if (targetPan && obj.ingredientType === 'meat') {
    obj.inPan = true;
    targetPan.mesh.add(obj.mesh);
    obj.mesh.position.set(0, 0.05, 0);
    obj.mesh.rotation.set(0, 0, 0);
    if (!targetPan.contents.includes(obj)) targetPan.contents.push(obj);
    return;
  }
  settleOnSurface(obj);
}

function releasePan(obj, worldPos) {
  for (const b of ZONE.burners) {
    if (worldPos.distanceTo(b.pos) < b.r) {
      obj.mesh.position.set(b.pos.x, b.pos.y + 0.03, b.pos.z);
      obj.onStove = true;
      return;
    }
  }
  obj.onStove = false;
  settleOnSurface(obj);
}

function releaseUtensil(obj, worldPos) {
  settleOnSurface(obj);
}

function discardPlate(plate) {
  scene.remove(plate.mesh);
  const i = plates.indexOf(plate);
  if (i !== -1) plates.splice(i, 1);
}

function tryServe(plate) {
  const need = currentOrder.items.slice();
  const have = plate.contents.slice();
  const ok = need.length === have.length && need.every(n => {
    const idx = have.findIndex(h => h.kind === n.kind && h.state === n.state);
    if (idx === -1) return false;
    have.splice(idx, 1);
    return true;
  });
  if (ok) {
    score += 100;
    document.getElementById('score').textContent = score;
    showToast(`🎉 ¡${currentOrder.name} servido! +100`);
    discardPlate(plate);
    nextOrder();
  } else {
    showToast('❌ Ese plato no coincide con el pedido');
  }
}

function releasePlate(obj, worldPos) {
  if (worldPos.distanceTo(ZONE.trash.pos) < ZONE.trash.r) {
    discardPlate(obj);
    showToast('🗑 Plato descartado');
    return;
  }
  if (worldPos.distanceTo(ZONE.pass.pos) < ZONE.pass.r) { tryServe(obj); return; }
  if (worldPos.distanceTo(ZONE.assembly.pos) < ZONE.assembly.r) {
    obj.mesh.position.set(worldPos.x, COUNTER_TOP_Y + 0.02, worldPos.z);
    return;
  }
  settleOnSurface(obj);
}

function handleGrabEnd(handKey, worldPos) {
  const obj = activeGrab[handKey];
  activeGrab[handKey] = null;
  if (!obj) return;
  obj.heldBy = null;
  if (obj.kind === 'plate') releasePlate(obj, worldPos);
  else if (obj.kind === 'pan') releasePan(obj, worldPos);
  else if (obj.kind === 'utensil') releaseUtensil(obj, worldPos);
  else releaseIngredient(obj, worldPos);
}

function updateHeldObjects() {
  for (const handKey of ['left', 'right']) {
    const obj = activeGrab[handKey];
    if (!obj) continue;
    const h = HandTracking.hands[handKey];
    const worldPos = handWorldPosition(h.palm.x, h.palm.y, h.palm.z, _tmpVec2);
    const target = worldPos.clone().add(obj.grabOffset);
    obj.mesh.position.lerp(target, 0.5);
  }
}

const _tmpVec = new THREE.Vector3(), _tmpVec2 = new THREE.Vector3();
function updateHandGesturesAndInteractions() {
  for (const handKey of ['left', 'right']) {
    const h = HandTracking.hands[handKey];
    const worldPos = handWorldPosition(h.palm.x, h.palm.y, h.palm.z, _tmpVec).clone();
    if (h.pinchStarted && !activeGrab[handKey]) handleGrabStart(handKey, worldPos);
    if (h.pinchEnded && activeGrab[handKey]) handleGrabEnd(handKey, worldPos);
  }
  updateHeldObjects();
}

// ---------- Picar ingredientes: requiere sostener el cuchillo ----------
const CHOP_HITS_REQUIRED = 4;
const _chopSpikeLatch = { left: false, right: false };
const _tmpChop = new THREE.Vector3();
let lastNoKnifeHint = 0;

function spawnChopFX(pos) {
  const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 });
  const spark = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 6), mat);
  spark.position.copy(pos).add(new THREE.Vector3(0, 0.05, 0));
  scene.add(spark);
  const start = performance.now();
  (function fade() {
    const t = (performance.now() - start) / 250;
    if (t >= 1) { scene.remove(spark); return; }
    spark.scale.setScalar(1 + t * 3);
    mat.opacity = 0.9 * (1 - t);
    requestAnimationFrame(fade);
  })();
}

function updateChopping() {
  for (const obj of ingredients) {
    if (!obj.onBoard) continue;
    const def = INGREDIENT_DEF[obj.ingredientType];
    if (!def.needsChop || obj.state !== 'raw') continue;

    for (const handKey of ['left', 'right']) {
      const h = HandTracking.hands[handKey];
      const worldPos = handWorldPosition(h.palm.x, h.palm.y, h.palm.z, _tmpChop);
      if (worldPos.distanceTo(obj.mesh.position) > 0.26) continue;

      const spikeEdge = h.chopSpike && !_chopSpikeLatch[handKey];
      _chopSpikeLatch[handKey] = h.chopSpike;
      if (!spikeEdge) continue;

      if (activeGrab[handKey] !== knife) {
        const now = performance.now();
        if (now - lastNoKnifeHint > 4000) {
          showToast('🔪 Necesitas sostener el cuchillo para picar');
          lastNoKnifeHint = now;
        }
        continue;
      }

      obj.choppedHits++;
      spawnChopFX(obj.mesh.position);
      if (obj.choppedHits >= CHOP_HITS_REQUIRED) {
        setIngredientState(obj, 'chopped');
        showToast(`🔪 ${def.label} picado`);
      }
    }
  }
}

// ---------- Remover con la espátula: acelera la cocción ----------
const _tmpStir = new THREE.Vector3();
const _stirLatch = { left: false, right: false };
function updateStirring() {
  for (const handKey of ['left', 'right']) {
    if (activeGrab[handKey] !== spatula) { _stirLatch[handKey] = false; continue; }
    const h = HandTracking.hands[handKey];
    const worldPos = handWorldPosition(h.palm.x, h.palm.y, h.palm.z, _tmpStir);
    const nearPan = findNearbyPan(worldPos, 0.28);

    const spikeEdge = h.chopSpike && !_stirLatch[handKey];
    _stirLatch[handKey] = h.chopSpike;
    if (!spikeEdge || !nearPan || !stoveOn) continue;

    for (const obj of nearPan.contents) {
      if (obj.state !== 'cooked') obj.cookProgress += 0.6;
    }
  }
}

// ---------- Cocinar en la estufa (para las 2 sartenes) ----------
const COOK_TIME = 3.5; // segundos para cocinar un ingrediente en el sartén
function updateCooking(dt) {
  if (!stoveOn) return;
  for (const p of pans) {
    if (!p.onStove) continue;
    for (const obj of p.contents) {
      if (obj.state === 'cooked') continue;
      obj.cookProgress += dt;
      if (obj.cookProgress >= COOK_TIME) {
        setIngredientState(obj, 'cooked');
        showToast(`🍳 ${INGREDIENT_DEF[obj.ingredientType].label} lista`);
      }
    }
  }
}

// ---------- Animación de puertas y llamas ----------
let fridgeDoorAngle = 0, entranceAngle = 0, clockT = 0;
function updateFridgeDoorAnim(dt) {
  fridgeDoorAngle = lerp(fridgeDoorAngle, fridgeOpen ? 1.3 : 0, Math.min(1, dt * 4));
  fridgeDoorMesh.rotation.y = fridgeDoorAngle;
  fridgeBottles.forEach(b => b.visible = fridgeOpen);
}
function updateEntranceDoorAnim(dt) {
  entranceAngle = lerp(entranceAngle, entranceOpen ? 1.1 : 0, Math.min(1, dt * 4));
  entranceDoorL.rotation.y = -entranceAngle;
  entranceDoorR.rotation.y = entranceAngle;
}
function updateFlameVisual() {
  flames.forEach(f => {
    f.visible = stoveOn;
    if (stoveOn) {
      const s = 1 + Math.sin(clockT * 14) * 0.12;
      f.scale.set(s, 1 + Math.sin(clockT * 11) * 0.15, s);
    }
  });
}

// ══════════════════════════════════════════════════════════
// PEDIDOS Y PUNTAJE
// ══════════════════════════════════════════════════════════
const RECIPES = [
  { name: 'Hamburguesa Especial', time: 75, items: [
      { kind: 'bun', state: 'raw' }, { kind: 'meat', state: 'cooked' },
      { kind: 'cheese', state: 'raw' }, { kind: 'lettuce', state: 'chopped' }
  ]},
  { name: 'Ensalada Fresca', time: 55, items: [
      { kind: 'lettuce', state: 'chopped' }, { kind: 'tomato', state: 'chopped' }, { kind: 'cheese', state: 'raw' }
  ]},
  { name: 'Hamburguesa Simple', time: 60, items: [
      { kind: 'bun', state: 'raw' }, { kind: 'meat', state: 'cooked' }, { kind: 'tomato', state: 'chopped' }
  ]}
];

let currentOrder = null, orderTimeLeft = 0, score = 0;

function renderOrderTicket() {
  document.getElementById('order-name').textContent = currentOrder.name;
  const ul = document.getElementById('order-items');
  ul.innerHTML = '';
  currentOrder.items.forEach(it => {
    const li = document.createElement('li');
    const extra = it.state === 'chopped' ? ' (picado)' : it.state === 'cooked' ? ' (cocido)' : '';
    li.textContent = INGREDIENT_DEF[it.kind].label + extra;
    ul.appendChild(li);
  });
}
function nextOrder() {
  let r;
  do { r = RECIPES[Math.floor(Math.random() * RECIPES.length)]; }
  while (RECIPES.length > 1 && currentOrder && r.name === currentOrder.name);
  currentOrder = r;
  orderTimeLeft = r.time;
  renderOrderTicket();
}
function updateOrderTimer(dt) {
  if (!currentOrder) return;
  orderTimeLeft -= dt;
  document.getElementById('order-timer').style.width = clamp(orderTimeLeft / currentOrder.time, 0, 1) * 100 + '%';
  if (orderTimeLeft <= 0) { showToast('⏰ ¡Pedido expirado!'); nextOrder(); }
}

// ---------- Toasts ----------
function showToast(text) {
  const wrap = document.getElementById('toast-wrap');
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = text;
  wrap.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 2200);
}

// ---------- HUD de manos ----------
const UTENSIL_LABEL = { knife: 'Cuchillo', spatula: 'Espátula', ladle: 'Cucharón' };
function updateHudHands() {
  const l = HandTracking.hands.left, r = HandTracking.hands.right;
  const pl = document.getElementById('pinch-l'), pr = document.getElementById('pinch-r');
  pl.style.width = (l.pinch * 100) + '%'; pl.classList.toggle('grabbing', l.isPinching);
  pr.style.width = (r.pinch * 100) + '%'; pr.classList.toggle('grabbing', r.isPinching);

  let status;
  if (!l.detected && !r.detected) status = 'Buscando manos… acércate a la cámara';
  else if (l.detected && r.detected) status = 'Ambas manos detectadas';
  else status = l.detected ? 'Mano izquierda detectada' : 'Mano derecha detectada';
  document.getElementById('status-text').textContent = status;

  const nameOf = (o) => {
    if (!o) return null;
    if (o.kind === 'plate') return `Plato (${o.contents.length} ing.)`;
    if (o.kind === 'pan') return 'Sartén';
    if (o.kind === 'utensil') return UTENSIL_LABEL[o.toolType];
    const extra = o.state !== 'raw' ? ` (${o.state === 'chopped' ? 'picado' : 'cocido'})` : '';
    return INGREDIENT_DEF[o.ingredientType].label + extra;
  };
  const l2 = nameOf(activeGrab.left), r2 = nameOf(activeGrab.right);
  const info = document.getElementById('held-info');
  info.innerHTML = (!l2 && !r2) ? 'Manos vacías' :
    [l2 ? `Izq: <b>${l2}</b>` : '', r2 ? `Der: <b>${r2}</b>` : ''].filter(Boolean).join(' · ');
}

// ══════════════════════════════════════════════════════════
// JUGADOR: movimiento en primera persona (teclado)
// — las manos quedan libres para los gestos frente a la cámara
// ══════════════════════════════════════════════════════════
const K = {};
window.addEventListener('keydown', e => { K[e.code] = true; });
window.addEventListener('keyup', e => { K[e.code] = false; });

const player = { pos: new THREE.Vector3(0, PLAYER_EYE, 2.6), yaw: 0, pitch: 0 };
const MOVE_SPEED = 2.0, TURN_SPEED = 1.6, LOOK_SPEED = 1.2;

function updatePlayerMovement(dt) {
  if (K['ArrowLeft']) player.yaw += TURN_SPEED * dt;
  if (K['ArrowRight']) player.yaw -= TURN_SPEED * dt;
  if (K['ArrowUp']) player.pitch = clamp(player.pitch + LOOK_SPEED * dt, -1.2, 1.2);
  if (K['ArrowDown']) player.pitch = clamp(player.pitch - LOOK_SPEED * dt, -1.2, 1.2);

  const sinY = Math.sin(player.yaw), cosY = Math.cos(player.yaw);
  const fwd = { x: -sinY, z: -cosY };
  const right = { x: cosY, z: -sinY };

  let mx = 0, mz = 0;
  if (K['KeyW']) { mx += fwd.x; mz += fwd.z; }
  if (K['KeyS']) { mx -= fwd.x; mz -= fwd.z; }
  if (K['KeyD']) { mx += right.x; mz += right.z; }
  if (K['KeyA']) { mx -= right.x; mz -= right.z; }

  const len = Math.hypot(mx, mz);
  if (len > 0.0001) {
    mx /= len; mz /= len;
    const resolved = resolvePlayerXZ(player.pos.x + mx * MOVE_SPEED * dt, player.pos.z + mz * MOVE_SPEED * dt);
    player.pos.x = resolved.x;
    player.pos.z = resolved.z;
  }

  camera.position.copy(player.pos);
  camera.rotation.set(player.pitch, player.yaw, 0, 'YXZ');
  camera.updateMatrixWorld(true);
}

// ══════════════════════════════════════════════════════════
// BUCLE PRINCIPAL
// ══════════════════════════════════════════════════════════
let lastT = performance.now();
function loop() {
  requestAnimationFrame(loop);
  const now = performance.now();
  const dt = Math.min((now - lastT) / 1000, 0.05);
  lastT = now;
  clockT += dt;

  updatePlayerMovement(dt);
  updateHandGesturesAndInteractions();
  updateHandVisuals();
  updateChopping();
  updateStirring();
  updateCooking(dt);
  updateFridgeDoorAnim(dt);
  updateEntranceDoorAnim(dt);
  updateFlameVisual();
  updateOrderTimer(dt);
  updateHudHands();

  renderer.render(scene, camera);
}

// ══════════════════════════════════════════════════════════
// ARRANQUE: pantalla de inicio -> permiso de cámara -> juego
// ══════════════════════════════════════════════════════════
const startBtn = document.getElementById('start-btn');
const startStatus = document.getElementById('start-status');

startBtn.addEventListener('click', async () => {
  startBtn.disabled = true;
  startStatus.textContent = 'Solicitando acceso a la cámara…';
  try {
    await HandTracking.start();
    document.getElementById('start-screen').classList.add('hidden');
    document.getElementById('hud').classList.remove('hidden');
    nextOrder();
    lastT = performance.now();
    requestAnimationFrame(loop);
  } catch (err) {
    startStatus.textContent = 'No se pudo acceder a la cámara: ' + (err && err.message ? err.message : err);
    startBtn.disabled = false;
  }
});

document.getElementById('restart-btn').addEventListener('click', () => location.reload());

})();
